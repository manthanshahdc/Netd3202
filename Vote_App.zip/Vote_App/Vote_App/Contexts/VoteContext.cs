﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Vote_App.Data.Entities;

namespace Vote_App.Contexts
{
    public class VoteContext : DbContext
    {
        public DbSet<Song> Songs { get; set; }
        public DbSet<Vote> Votes { get; set; }
        public DbSet<User> Users { get; set; }

        public VoteContext(DbContextOptions options) : base(options)
        {
        }
    }
}
