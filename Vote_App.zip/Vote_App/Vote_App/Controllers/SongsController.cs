﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Vote_App.Contexts;
using Microsoft.AspNetCore.Authorization;

namespace Vote_App.Controllers
{
    // This controller will be mainly used for Songs' related modification
    public class SongsController : Controller
    {
        VoteContext voteContext;

        // To show the list of songs with number of votes given by that particular User
        public IActionResult Index()
        {
            var model = new Models.SongsHomeModel(voteContext.Songs.Include("Votes").ToList(), getUserId());
            return View(model);
        }

        // Initializig context
        public SongsController(VoteContext context)
        {
            voteContext = context;
        }
        
        // Navigating to the Edit page for the song to change it's details
        [Route("/Songs/Manage/{id?}")]
        public IActionResult Manage(int id = 0)
        {
            var model = new Models.ManageSongModel();
            model.RequestedId = id;

            // Checking that song exist or not
            if (id.Equals(0))
                model.NewSong = true;

            else
            {
                // Getting record for that song
                var song = voteContext.Songs.Where(r => r.Id.Equals(id)).FirstOrDefault();

                // Updating song if data found
                if (song != null)
                {
                    model.Song = new Models.Song(song, getUserId());
                }
            }

            // Redirecting to view
            return View(model);
        }

        // To save the song details
        [HttpPost]
        public IActionResult SaveSong(Models.Song song)
        {
            // Searching for Song
            if (song.Id > 0)
            {
                var data = voteContext.Songs.Where(r => r.Id.Equals(song.Id)).FirstOrDefault();

                if (data == null)
                {
                    throw new Exception("song not found");
                }
                
                // If song found then change the description
                data.Description = song.Description;
            }
            else
            {
                // Adding a new song
                voteContext.Songs.Add(new Data.Entities.Song()
                {
                    Description = song.Description,
                    Title = song.Title
                });
            }

            // Saving Data
            voteContext.SaveChanges();

            return RedirectToAction("Index", "Songs", null);
        }

        // To delete the songs details this method will be used
        [HttpGet]
        public IActionResult RemoveSong(int id)
        {
            try
            {
                var song = voteContext.Songs.Where(r => r.Id.Equals(id)).FirstOrDefault();

                if (song == null)
                    throw new Exception("no song found");

                voteContext.Songs.Remove(song);
                voteContext.SaveChanges();

                return RedirectToAction("Index", "Songs", null);
            }
            catch (Exception e)
            {
                return RedirectToAction("Index", "Songs", null);
            }
        }

        // To increase the song votes
        [HttpPost]
        public IActionResult UpvoteSong(int id)
        {
            try
            {
                // Searching for song
                var song = voteContext.Songs.Where(r => r.Id.Equals(id)).FirstOrDefault();

                if (song == null)
                    throw new Exception("no song found");

                var vote = voteContext.Votes.Where(r => r.UserId.Equals(getUserId()) && r.SongId.Equals(id)).FirstOrDefault();

                if (vote == null)
                {
                    voteContext.Votes.Add(new Data.Entities.Vote()
                    {
                        SongId = id,
                        UserId = getUserId(),
                        Value = 1
                    });

                    song.CurrentVotes += 1;
                }
                else
                {
                    song.CurrentVotes -= vote.Value;

                    if (vote.Value == 1)
                    {
                        vote.Value = 0;
                    }
                    else
                    {
                        vote.Value = 1;
                        song.CurrentVotes += 1;
                    }
                }

                voteContext.SaveChanges();
                if (vote == null)
                    vote = voteContext.Votes.Where(r => r.UserId.Equals(getUserId()) && r.SongId.Equals(id)).FirstOrDefault();

                return new JsonResult(new Models.VoteSongResponse()
                {
                    CurrentVotes = song.CurrentVotes,
                    UserVote = vote.Value,
                    Success = true
                });
            }
            catch (Exception e)
            {
                return new JsonResult(new Models.VoteSongResponse()
                {
                    Success = false
                });
            }
        }

        // To reduce the songs votes
        [HttpPost]
        public IActionResult DownvoteSong(int id)
        {
            try
            {
                // Searching for song
                var song = voteContext.Songs.Where(r => r.Id.Equals(id)).FirstOrDefault();

                if (song == null)
                    throw new Exception("no song found");

                var vote = voteContext.Votes.Where(r => r.UserId.Equals(getUserId()) && r.SongId.Equals(id)).FirstOrDefault();

                if (vote == null)
                {
                    voteContext.Votes.Add(new Data.Entities.Vote()
                    {
                        SongId = id,
                        UserId = getUserId(),
                        Value = -11
                    });

                    song.CurrentVotes -= 1;
                }
                else
                {
                    song.CurrentVotes -= vote.Value;

                    if (vote.Value == -1)
                    {
                        vote.Value = 0;
                    }
                    else
                    {
                        vote.Value = -1;
                        song.CurrentVotes -= 1;
                    }
                }

                voteContext.SaveChanges();

                return new JsonResult(new Models.VoteSongResponse()
                {
                    CurrentVotes = song.CurrentVotes,
                    UserVote = vote.Value,
                    Success = true
                });
            }
            catch (Exception e)
            {
                return new JsonResult(new Models.VoteSongResponse()
                {
                    Success = false
                });
            }
        }

        // To get the userId for the current user
        protected int getUserId()
        {
            return voteContext.Users.Where(r => r.Username.Equals("username")).First().Id;
        }
    }
}
