﻿using System;
using System.Collections.Generic;

using System.Linq;
using System.Threading.Tasks;

namespace Vote_App.Models
{
    // Song Model which store song's information
    public class Song
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public int CurrentVotes { get; set; }

        public int UserVote { get; set; }

        // Parameterized constructior
        public Song(Data.Entities.Song song, int userId)
        {
            Id = song.Id;
            Title = song.Title;
            Description = song.Description;
            CurrentVotes = song.CurrentVotes;

            if (song.Votes == null)
                return;

            var userVote = song.Votes.Where(r => r.UserId.Equals(userId)).FirstOrDefault();

            if (userVote != null)
            {
                UserVote = userVote.Value;
            }
        }

        // Default Constructor
        public Song()
        {

        }
    }
}
