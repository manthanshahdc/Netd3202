﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Vote_App.Models
{
    // To create and update this model will be used
    public class ManageSongModel
    {
        public int RequestedId { get; set; }
        public bool NewSong { get; set; }
        public bool SongFound { get { return Song != null || NewSong; } }
        public Song Song { get; set; }
    }
}
