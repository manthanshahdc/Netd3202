﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Vote_App.Models
{
    // To show the list of songs with all the details this model will be used
    public class SongsHomeModel
    {
        public List<Song> Songs { get; set; }

        public SongsHomeModel(List<Data.Entities.Song> songs, int userId)
        {
            Songs = new List<Song>();

            foreach (var song in songs)
            {
                Songs.Add(new Song(song, userId));
            }
        }
    }
}
