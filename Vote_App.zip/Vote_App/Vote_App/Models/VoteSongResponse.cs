﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Vote_App.Models
{
    // To show the songs' votes this model will be used
    public class VoteSongResponse
    {
        public bool Success { get; set; }
        public int CurrentVotes { get; set; }
        public int UserVote { get; set; }
    }
}
