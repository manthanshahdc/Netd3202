﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Vote_App.Models
{
    // Model vote which connected to Song and the User
    public class Vote
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public int SongId { get; set; }
        public int Value { get; set; }

        public Song song { get; set; }
        public User User { get; set; }
    }
}
