﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Vote_App.Models
{
    // User model which stores User information
    public class User
    {
        public int Id { get; set; }
        public string Username { get; set; }

        public List<Vote> Votes { get; set; }
    }
}
