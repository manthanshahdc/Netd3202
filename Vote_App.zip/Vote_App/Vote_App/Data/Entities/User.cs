﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Vote_App.Data.Entities
{
    public class User
    {
        // Unique Id for User
        [Key]
        public int Id { get; set; }
        // Username for the user
        public string Username { get; set; }

        public List<Vote> Votes { get; set; }
    }
}
