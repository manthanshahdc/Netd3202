﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Vote_App.Data.Entities
{
    // Song entity which stores data information for song
    public class Song
    {
        // Unique Id for song
        [Key]
        public int Id { get; set; }
        // Title for song
        public string Title { get; set; }
        // Description of Song
        public string Description { get; set; }
        // Cuurent votes given by User to the song
        public int CurrentVotes { get; set; }

        public List<Vote> Votes { get; set; }
    }
}
